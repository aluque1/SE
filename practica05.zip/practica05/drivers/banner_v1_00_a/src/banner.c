/*****************************************************************************
* Filename:          C:\Users\aluqu\Desktop\uni\SE\practica05/drivers/banner_v1_00_a/src/banner.c
* Version:           1.00.a
* Description:       banner Driver Source File
* Date:              Sat Dec 16 19:06:47 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "banner.h"

/************************** Function Definitions ***************************/

