/*****************************************************************************
* Filename:          C:\Users\aluqu\Desktop\uni\SE\practica03/drivers/peripheral_practica03_v1_00_a/src/peripheral_practica03.c
* Version:           1.00.a
* Description:       peripheral_practica03 Driver Source File
* Date:              Sun Dec 10 13:08:50 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "peripheral_practica03.h"

/************************** Function Definitions ***************************/

