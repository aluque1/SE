/*****************************************************************************
* Filename:          C:\Users\aluqu\Desktop\uni\SE\practica04/drivers/pantalla_v1_00_a/src/pantalla.c
* Version:           1.00.a
* Description:       pantalla Driver Source File
* Date:              Wed Dec 13 14:02:28 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "pantalla.h"

/************************** Function Definitions ***************************/

